<?php

class Pcodes_guide {

    static function init() {

        add_filter( 'bwg_support', array( 'Pcodes_guide', 'guide_support' ) );

        # peenapo guide support
        add_action( 'bwg_support_updates-peenapo',  array( 'Pcodes_guide', 'bwg_support_updates_peenapo' ) );
        add_action( 'bwg_support_updates-envato',   array( 'Pcodes_guide', 'bwg_support_updates_envato' ) );
        add_action( 'bwg_support_import',           array( 'Pcodes_guide', 'bwg_support_import' ) );
        add_action( 'bwg_support_google-maps',      array( 'Pcodes_guide', 'bwg_support_google_maps' ) );
        add_action( 'bwg_support_customize',        array( 'Pcodes_guide', 'bwg_support_customize' ) );
        add_action( 'bwg_support_get-involved',     array( 'Pcodes_guide', 'bwg_support_get_involved' ) );
        add_action( 'bwg_support_dev',              array( 'Pcodes_guide', 'bwg_support_dev' ) );

    }

    static function guide_support( $support ) {

        $support = array_merge( $support, array(
            //'updates-envato'      => array( 'label' => esc_html__('Updates', 'peenapo-codes-td'), 'all_visible' => true ),
            'updates-peenapo'       => array( 'label' => esc_html__('Updates', 'peenapo-codes-td'), 'all_visible' => true ),
            'import'                => array( 'label' => esc_html__('Import Demo', 'peenapo-codes-td'), 'all_visible' => true ),
            'google-maps'           => array( 'label' => esc_html__('Maps', 'peenapo-codes-td'), 'all_visible' => true ),
            'customize'             => array( 'label' => esc_html__('Customize', 'peenapo-codes-td'), 'all_visible' => true ),
            'get-involved'          => array( 'label' => esc_html__('Get Involved', 'peenapo-codes-td'), 'all_visible' => true ),
        ));

        if( Bw_guide::$is_peenapo_user ) { $support['dev'] = array( 'label' => esc_html__('Dev', 'peenapo-codes-td'), 'all_visible' => false ); }

        return $support;

    }

    static function bwg_support_updates_envato() {
        include( PCODES_ROOT . '/lib/guide/support/updates_envato.php' );
    }

    static function bwg_support_updates_peenapo() {
        include( PCODES_ROOT . '/lib/guide/support/updates_peenapo.php' );
    }

    static function bwg_support_import() {
        include( PCODES_ROOT . '/lib/guide/support/import.php' );
    }

    static function bwg_support_google_maps() {
        include( PCODES_ROOT . '/lib/guide/support/google_maps.php' );
    }

    static function bwg_support_customize() {
        include( PCODES_ROOT . '/lib/guide/support/customize.php' );
    }

    static function bwg_support_get_involved() {
        include( PCODES_ROOT . '/lib/guide/support/involved.php' );
    }

    static function bwg_support_dev() {
        include( PCODES_ROOT . '/lib/guide/support/dev.php' );
    }

}
Pcodes_guide::init();

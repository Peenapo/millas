<?php

class Pcodes {

    static $config;

	# list of users who can edit custom field definitions here
    static $user_display = array(
        'badweather',
        'peenapo',
        'demo',
    );
	static $is_peenapo_user = false;
	static $customizer_export = false;
	static $theme;

    static $acf_export_path;

    static function init() {

		# theme data
		self::$theme = wp_get_theme();
		# check if one of ours
		if( strtolower( self::$theme->get( 'Author' ) ) !== 'peenapo' ) { return; }

		# some themes are using the old engine, so we will skip this themes
		if( in_array( strtolower( self::$theme->get( 'Name' ) ), array('panama', 'peliegro', 'santino', 'marroco', 'trend') ) ) { return; }

		# general
        add_action( 'plugins_loaded', array('Pcodes', 'general') );
        # init advanced custom fields
		add_action( 'plugins_loaded', array( 'Pcodes', 'init_acf' ) );
        # enqueue some scripts
        add_action( 'init', array('Pcodes', 'enqueue_scripts') );
        # admin
        add_action( 'admin_init', array('Pcodes', 'admin_init') );
        # export customizer options on save ( available in production mode )
        add_action( 'customize_save_after', array( 'Pcodes', 'export_customizer_on_save' ) );
        # move site identity customizer section under General panel
        add_action( 'customize_register', array( 'Pcodes', 'title_tagline' ), 12 );

    }

    static function title_tagline( WP_Customize_Manager $wp_customize ) {

        $tagline_section = $wp_customize->get_section( 'title_tagline' );

        if( $tagline_section instanceof WP_Customize_Section ) {
            $tagline_section->priority = 1;
            $tagline_section->panel = Bw::$theme_prefix . '_general';
        }
    }

	static function export_customizer_on_save() {

        if( self::$customizer_export and defined( 'BW_PRODUCTION' ) and BW_PRODUCTION == true ) {

            $file = get_template_directory() . '/bw/demo/1/theme-mods.txt';

            #if ( is_writable( $file ) ) {

                # initialize the Wordpress filesystem, no more using file_put_contents function
                global $wp_filesystem;
                if ( empty( $wp_filesystem ) ) {
                    require_once( ABSPATH . '/wp-admin/includes/file.php' );
                    WP_Filesystem();
                }

                # get options
                $mods_export = '';
                if( defined('BW_FRAME_LIB') ) {
                    $customizer_mods_file = BW_FRAME_LIB . 'customizer/customizer-mods.php';
                    if( file_exists( $customizer_mods_file ) ) {
                        require $customizer_mods_file;
                        $options_arr = array();
                        foreach( $options as $option ) {
                            $value = get_option( $option['id'] );
                            if( empty( $value ) ) {
                                if( isset( $option['default'] ) ) {
                                    $value = $option['default'];
                                }
                            }
                            $site_url = get_site_url();
                            if( strpos( $value, $site_url ) !== false  ) {
                                $value = str_replace( $site_url, '%BW_SITE_URL%', $value );
                            }
                            $options_arr[ $option['id'] ] = $value;
                        }
                        $mods_export = maybe_serialize( $options_arr );
                    }
                }

                $wp_filesystem->put_contents( $file, $mods_export, FS_CHMOD_FILE );
            #}

        }

    }

	static function general() {

		# path to export file
		self::$acf_export_path = get_template_directory() . '/bw/demo/theme-acf-options.php';

		# check if acf is on and fix fn get_field
        add_action( 'wp', array( 'Pcodes', 'acf_fn_get_field' ) );

        # check user
		self::is_peenapo_user();

        include_once( PCODES_ROOT . 'lib/customizer/Bw_customizer.php' );

	}

    static function load_textdomain() {
        load_plugin_textdomain( 'peenapo-codes-td', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/');
    }

    static function acf_fn_get_field() {

        if( ! function_exists( 'get_field' ) ) {
            include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
            if( ! is_plugin_active( 'advanced-custom-fields/acf.php' ) ) {
                function get_field() { return; }
            }
        }
    }

	static function is_peenapo_user() {

        # get the current user
		global $current_user;
		$current_user = wp_get_current_user();

        # check list of admin users
        self::$is_peenapo_user = in_array( strtolower( $current_user->user_login ), self::$user_display ) ? true : false;
    }

    static function init_acf() {

		if( class_exists('Bw') and in_array( 'meta', Bw::$startup_classes ) ) { return; }

        # include ACF
        include_once( PCODES_ROOT . 'lib/acf/acf.php' );

		# load cached acf option settings
		if( ! ( defined( 'BW_PRODUCTION' ) and BW_PRODUCTION == true ) ) {
			if( file_exists( Pcodes::$acf_export_path ) ) {
				include_once( Pcodes::$acf_export_path );
			}
		}

		# remove fields for standard users
		add_action( 'admin_menu', array( 'Pcodes', 'remove_acf_menu' ), 999 );

		# automatic acf field export. Export is initiated whenever an admin
		# publishes a new field group or saves changes to an existing field group.
		if( is_admin() and Pcodes::$is_peenapo_user ) {
			add_action('admin_head-post.php', array( 'Pcodes', 'automatic_acf_export' ) );
		}

        # register acf addons
        self::acf_addons();
    }

    static function remove_acf_menu() {
        if( ! self::$is_peenapo_user and ! self::is_acf_plugin_active() ) {
            remove_menu_page( 'edit.php?post_type=acf' );
        }
    }

    static function is_acf_plugin_active() {
        return in_array( 'advanced-custom-fields/acf.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ? true : false;
    }

    static function automatic_acf_export() {

        # only continue if saving acf post, is not a micro site, is not a child theme
        if( get_post_type() !== 'acf' or ! is_main_site() or ! defined( 'BW_PRODUCTION' ) ) { return; }

        # only continue if we're saving a field group
        if ( empty( $_GET['message'] ) || ( $_GET['message'] != '1' && $_GET['message'] != '6' ) ) { return; }

        $acf = new acf_field_group();

        $fields = array();
        $fields = get_posts(array(
            'numberposts'   => -1,
            'post_type'     => 'acf',
            'orderby'       => 'menu_order title',
            'order'         => 'asc',
        ));

        if( $fields ) {

            $output = '<?php

if(function_exists("register_field_group")) {
    ';

            foreach( $fields as $field ) {

                $uniqid = uniqid();

                $var = array(
                    'id' => $field->post_name,
                    'title' => get_the_title($field->ID),
                    'fields' => $acf->get_fields(array(), $field->ID),
                    'location' => $acf->get_location(array(), $field->ID),
                    'options' => $acf->get_options(array(), $field->ID),
                    'menu_order' => $field->menu_order,
                );

                $html = var_export($var, true);
                $html = str_replace("  ", "\t", $html); // change double spaces to tabs
                $html = str_replace("\n", "\n\t", $html); // add extra tab at start of each line
                $html = str_replace("array (", "array(", $html); // remove excess space from beginning of arrays

                $output .= '
    register_field_group('.$html.'); ';

            }

            $output .= '
}';

        }

        $file = self::$acf_export_path;

        if ( is_writable( $file ) ) {

            # Initialize the Wordpress filesystem, no more using file_put_contents function
            global $wp_filesystem;
            if ( empty( $wp_filesystem ) ) {
                require_once( ABSPATH . '/wp-admin/includes/file.php' );
                WP_Filesystem();
            }
            $wp_filesystem->put_contents( $file, $output, FS_CHMOD_FILE );
            //file_put_contents( $file, $output );
            define( 'ACF_EXPORT_FILE', $file );
            add_action( 'admin_notices', array( 'Pcodes', 'acf_export_success' ) );
        }  else {
            add_action( 'admin_notices', array( 'Pcodes', 'acf_export_fail' ) );
        }
    }

    static function acf_export_success( $file = '' ) {
        if ( defined( 'ACF_EXPORT_FILE' ) ) {
            $destination = ' to <strong>' . ACF_EXPORT_FILE . '</strong>';
        } else {
            $destination = '';
        }
        echo '<div class="updated"><p>All fields successfully exported'.$destination.'.</p></div>';
    }

    static function acf_export_fail( $file = '' ) {
        echo '<div class="error"><p><strong>Automated Export Error:</strong> The export file you\'ve specified is not writeable.</p></div>';
    }

    static function acf_addons() {
        include_once( PCODES_ROOT . 'lib/acf/add-ons/acf-flexible-content/flexible-content.php');
        include_once( PCODES_ROOT . 'lib/acf/add-ons/acf-repeater/repeater.php');
    }

    # enqueue some scripts
    static function enqueue_scripts() {
        if( is_admin() ) {
            wp_enqueue_script( 'bw-acf-custom', PCODES_URI . 'lib/acf/js/custom-admin.js', array('jquery-ui'), '1.0', true );
            #wp_dequeue_style( 'jquery-ui-css' );
            wp_enqueue_style( 'jquery-ui-slider-css', PCODES_URI . 'lib/acf/css/jquery-ui.slider.css' );
            wp_enqueue_style( 'pe-7-stroke', PCODES_URI . 'assets/css/fonts/pe-7stroke/pe-icon-7-stroke.css' );
        }

    }

    static function admin_init() {
        if ( is_plugin_active( 'advanced-custom-fields/acf.php' ) ) {
            deactivate_plugins('advanced-custom-fields/acf.php');
        }
    }
}

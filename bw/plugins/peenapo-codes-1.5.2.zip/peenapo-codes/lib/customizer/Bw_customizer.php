<?php

/**
 * This function defines the constants
 */
define( 'WPC_DIR', PCODES_ROOT . 'lib/customizer/' );
define( 'WPC_URL', PCODES_URI . 'lib/customizer/' );

class Bw_customizer {

    static $saving_type;

    static function init() {

        self::saving_type();

        # require custom control class
        require_once trailingslashit( WPC_DIR ) . 'inc/class-wp-customize-control.php';

        # register settings
        add_action( 'after_switch_theme', array('Bw_customizer', 'register_settings') );

        # define settings file
        add_action( 'customize_register', array('Bw_customizer', 'customizer_register') );

        # enqueue styles
        add_action( 'customize_controls_enqueue_scripts', array('Bw_customizer', 'scripts') );

        # enqueue automate preview script
        add_action( 'customize_preview_init', array('Bw_customizer', 'customize_live_preview') );

        # create custom controls
        add_action( 'bwpc_create_custom_control', array( 'Bw_customizer', 'create_custom_controls'), 10, 1 );

        # output styles
        add_action( 'wp_enqueue_scripts', array( 'Bw_customizer', 'output_style' ), 50 );

        # output styles live
        if ( isset( $GLOBALS['wp_customize'] ) ) {
            add_action( 'wp_head', array( 'Bw_customizer', 'output_style_live' ), 90 );
        }

    }

    static function saving_type() {
        self::$saving_type = apply_filters( 'bwpc_saving_type', 'option' );
    }

    # detect support for Customizer panels
    static function panel_support() {
        return ( class_exists( 'WP_Customize_Manager' ) && method_exists( 'WP_Customize_Manager', 'add_panel' ) ) || function_exists( 'wp_validate_boolean' );
    }

    # define settings file
    static function customizer_file() {

        return BW_FRAME_LIB . 'customizer/customizer-mods.php';

    }

    static function register_settings() {

        require Bw_customizer::customizer_file();

        foreach ( $options as $option ) {
            if ( $option['type'] != 'panel' && $option['type'] != 'section' ) {
                if ( ! get_option( $option['id'] ) ) {
                    update_option( $option['id'], $option['default'] );
                }
            }
        }

    }

    static function scripts() {

        wp_enqueue_style( 'bw-customize-styles', PCODES_URI . 'lib/customizer/assets/css/style.css' );

        wp_register_script( 'bw-ace-editor', PCODES_URI . 'lib/customizer/assets/js/ace/ace.js', array('jquery'), false, true );

        wp_enqueue_script( 'bw-customize-scripts', PCODES_URI . 'lib/customizer/assets/js/main.js', array( 'jquery', 'customize-controls', 'bw-ace-editor' ), false, true );

    }

    static function customize_live_preview() {

        wp_enqueue_script('bwpc-customizer-auto-preview', PCODES_URI . 'lib/customizer/assets/js/customizer_preview.js', array( 'jquery', 'customize-preview' ), '', true);

    }

    static function create_custom_controls( $wp_customize ) {

        // custom controls ..

    }

    // output customizer styles
    static function output_style() {

        require Bw_customizer::customizer_file();

        $customizer_css = '';
        foreach ( $options as $option ) {
            if( isset( $option['css'] ) ) {
                $customizer_css .= self::convert_setting_to_css( $option );
            }
		}

        wp_add_inline_style( 'bw-style-theme', wp_strip_all_tags( $customizer_css ) );



    }

    static function output_style_live() {

        self::output_dynamic_style();

    }

    static function convert_setting_to_css( $option ) {

        $css = (object)$option['css'];

        if( isset( $css->property ) and isset( $css->selector ) ) {
            if( ! isset( $css->unity ) ) { $css->unity = ''; }

            $option = get_option( $option['id'], $option['default'] );

            return "{$css->selector} {{$css->property}:{$option}{$css->unit};}";
        }elseif( is_array( $option['css'] ) ) {
            $output = '';
            foreach( $option['css'] as $property_css ) {
                $output .= self::convert_setting_to_css(array(
                    'id' => $option['id'],
                    'default' => $option['default'],
                    'css' => $property_css
                ));
            }
            return $output;
        }

    }

    static function output_dynamic_style() {

        require Bw_customizer::customizer_file();

        $output_styles = '';

        foreach( $options as $option ) {

            $option = (object)$option;

            if( isset( $option->css ) ) {

                if( isset( $option->css['property'] ) and isset( $option->css['selector'] ) ) {

                    $css = (object)$option->css;
                    $css_code = '';
                    if( ! isset( $css->unity ) ) { $css->unity = ''; }

                    $theme_mod = get_option( $option->id, $option->default );
                    $css_code .= "{$css->selector} {{$css->property}:{$theme_mod}{$css->unit};}";

                    $output_styles .= "<style type='text/css' id='bw-dynamic-customizer-output-{$option->id}' data-property='{$css->property}' data-selector='{$css->selector}' data-unit='{$css->unit}'>";
                    $output_styles .= $css_code;
                    $output_styles .= "</style>";

                }elseif( is_array( $option->css ) ) {

                    $css_code = '';
                    $data = "data-properties='" . count( $option->css ) . "'";

                    foreach( $option->css as $key => $css_prop ) {

                        $k = $key + 1;

                        if( isset( $css_prop['property'] ) and isset( $css_prop['selector'] ) ) {

                            $css = (object)$css_prop;

                            if( ! isset( $css->unity ) ) { $css->unity = ''; }

                            $theme_mod = get_option( $option->id, $option->default );
                            $css_code .= "{$css->selector} {{$css->property}:{$theme_mod}{$css->unit};}";

                            $data .= " data-property-{$k}='{$css->property}' data-selector-{$k}='{$css->selector}' data-unit-{$k}='{$css->unit}'";

                        }
                    }

                    $output_styles .= "<style type='text/css' id='bw-dynamic-customizer-output-{$option->id}' class='bw-dynamic-multiple' {$data}>";
                    $output_styles .= $css_code;
                    $output_styles .= "</style>";

                }
            }
        }

        echo $output_styles;

    }

    # add postMessage support for site title and description for the Theme Customizer
    static function custom_transport_support( $wp_customize ) {
        $wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
    	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
    	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';
    }

    static function customizer_register( $wp_customize ) {

        Bw_customizer::custom_transport_support( $wp_customize );

        // Require customizer options file
        require Bw_customizer::customizer_file();

        $type = 'option'; // option / theme_mod

        $i = 0;

        if( Bw_customizer::panel_support() ) {

            foreach ( $options as $option ) {

                // Add panel - WP 4.0+ only
                if ( $option['type'] == 'panel' ) {

                    $priority       = ( isset( $option['priority'] ) ) ? $option['priority'] : $i + 10;
                    $theme_supports = ( isset( $option['theme_supports'] ) ) ? $option['theme_supports'] : '';
                    $title          = ( isset( $option['title'] ) ) ? esc_attr( $option['title'] ) : __( 'Untitled Panel', 'wpc' );
                    $description    = ( isset( $option['description'] ) ) ? esc_attr( $option['description'] ) : '';

                    $wp_customize->add_panel( $option['id'], array(
                        'priority'          => $priority,
                        'capability'        => $capability,
                        'theme_supports'    => $theme_supports,
                        'title'             => $title,
                        'description'       => $description,
                    ) );

                }

                // Add sections
                if ( $option['type'] == 'section'  ) {

                    $priority       = ( isset( $option['priority'] ) ) ? $option['priority'] : $i + 10;
                    $theme_supports = ( isset( $option['theme_supports'] ) ) ? $option['theme_supports'] : '';
                    $title          = ( isset( $option['title'] ) ) ? esc_attr( $option['title'] ) : __( 'Untitled Section', 'wpc' );
                    $description    = ( isset( $option['description'] ) ) ? esc_attr( $option['description'] ) : '';
                    $panel          = ( isset( $option['panel'] ) ) ? esc_attr( $option['panel'] ) : '';

                    $options_arr = array(
                        'priority'          => $priority,
                        'capability'        => $capability,
                        'theme_supports'    => $theme_supports,
                        'title'             => $title,
                        'description'       => $description,
                        'panel'             => $panel,
                    );
                    if( isset( $option['panel'] ) ) { $options_arr['panel'] = $panel; }

                    $wp_customize->add_section( esc_attr( $option['id'] ), $options_arr );

                }

                // add controls
                if ( $option['type'] == 'control' ) {

                    $priority           = ( isset( $option['priority'] ) ) ? $option['priority'] : $i + 10;
                    $section            = ( isset( $option['section'] ) ) ? esc_attr( $option['section'] ) : '';
                    $default            = ( isset( $option['default'] ) ) ? $option['default'] : '';
                    $transport          = ( isset( $option['transport'] ) ) ? esc_attr( $option['transport'] ) : 'refresh';
                    $title              = ( isset( $option['title'] ) ) ? esc_attr( $option['title'] ) : __( 'Untitled Section', 'wpc' );
                    $description        = ( isset( $option['description'] ) ) ? esc_attr( $option['description'] ) : '';
                    $form_field         = ( isset( $option['option'] ) ) ? esc_attr( $option['option'] ) : 'option';
                    $sanitize_callback  = ( isset( $option['sanitize_callback'] ) ) ? esc_attr( $option['sanitize_callback'] ) : '';
                    $store_type         = ( isset( $option['store_type'] ) ) ? esc_attr( $option['store_type'] ) : self::$saving_type;

                    // add control settings
                    $wp_customize->add_setting( esc_attr( $option['id'] ), array(
                        'default' => $default,
                        'type' => $store_type,
                        'capability' => $capability,
                        'transport' => $transport,
                        'label' => $title,
                        'sanitize_callback' => $sanitize_callback,
                    ));

                    // Add form field
                    switch ( $form_field ) {

                        // URL Field
                        case 'url':
                            $wp_customize->add_control( esc_attr( $option['id'] ), array(
                                'type'              => 'url',
                                'priority'          => $priority,
                                'section'           => $section,
                                'label'             => $title,
                                'description'       => $description,
                            ) );
                        break;

                        // URL Field
                        case 'email':
                            $wp_customize->add_control( esc_attr( $option['id'] ), array(
                                'type'              => 'email',
                                'priority'          => $priority,
                                'section'           => $section,
                                'label'             => $title,
                                'description'       => $description,
                            ) );
                        break;

                        // Password Field
                        case 'password':
                            $wp_customize->add_control( esc_attr( $option['id'] ), array(
                                'type'              => 'password',
                                'priority'          => $priority,
                                'section'           => $section,
                                'label'             => $title,
                                'description'       => $description,
                            ) );
                        break;

                        // Range Field
                        case 'range':
                            $input_attrs = ( isset( $option['input_attrs'] ) ) ? $option['input_attrs'] : array();
                            $wp_customize->add_control( esc_attr( $option['id'] ), array(
                                'type'              => 'range',
                                'priority'          => $priority,
                                'section'           => $section,
                                'label'             => $title,
                                'description'       => $description,
                                'input_attrs'       => $input_attrs,
                            ) );
                        break;

                        // Text Field
                        case 'text':
                            $input_attrs = ( isset( $option['input_attrs'] ) ) ? $option['input_attrs'] : array();
                            $wp_customize->add_control( esc_attr( $option['id'] ), array(
                                'type'              => 'text',
                                'priority'          => $priority,
                                'section'           => $section,
                                'label'             => $title,
                                'description'       => $description,
                                'input_attrs'       => $input_attrs,
                            ) );
                        break;

                        // Radio Field
                        case 'radio':
                            $choices  = ( isset( $option['choices'] ) ) ? $option['choices'] : array();

                            $wp_customize->add_control( esc_attr( $option['id'] ), array(
                                'type'              => 'radio',
                                'priority'          => $priority,
                                'section'           => $section,
                                'label'             => $title,
                                'description'       => $description,
                                'choices'           => $choices,
                            ) );
                        break;

                        // Checkbox Field
                        case 'checkbox':
                            $wp_customize->add_control( esc_attr( $option['id'] ), array(
                                'type'              => 'checkbox',
                                'priority'          => $priority,
                                'section'           => $section,
                                'label'             => $title,
                                'description'       => $description,
                            ) );
                        break;

                        // Radio Field
                        case 'select':
                            $choices  = ( isset( $option['choices'] ) ) ? $option['choices'] : array();

                            $wp_customize->add_control( esc_attr( $option['id'] ), array(
                                'type'              => 'select',
                                'priority'          => $priority,
                                'section'           => $section,
                                'label'             => $title,
                                'description'       => $description,
                                'choices'           => $choices,
                            ) );
                        break;

                        // Image Upload Field
                        case 'image':
                            $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, esc_attr( $option['id'] ), array(
                                'priority'          => $priority,
                                'section'           => $section,
                                'label'             => $title,
                                'description'       => $description,
                            )));
                        break;

                        // File Upload Field
                        case 'file':
                            $wp_customize->add_control( new WP_Customize_Upload_Control( $wp_customize, esc_attr( $option['id'] ), array(
                                'priority'          => $priority,
                                'section'           => $section,
                                'label'             => $title,
                                'description'       => $description,
                            )));
                        break;

                        // Color Picker Field
                        case 'color':
                            $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, esc_attr( $option['id'] ), array(
                                'priority'          => $priority,
                                'section'           => $section,
                                'label'             => $title,
                                'description'       => $description,
                            )));
                        break;

                        // Pages Field
                        case 'pages':
                            $wp_customize->add_control( esc_attr( $option['id'] ), array(
                                'type'              => 'dropdown-pages',
                                'priority'          => $priority,
                                'section'           => $section,
                                'label'             => $title,
                                'description'       => $description,
                            ) );
                        break;

                        // Categories Field
                        case 'categories':
                            $wp_customize->add_control( new WPC_Customize_Categories_Control( $wp_customize, esc_attr( $option['id'] ), array(
                                'priority'          => $priority,
                                'section'           => $section,
                                'label'             => $title,
                                'description'       => $description,
                            )));
                        break;

                        // Textarea Field
                        case 'textarea':
                            $wp_customize->add_control( new WPC_Customize_Textarea_Control( $wp_customize, esc_attr( $option['id'] ), array(
                                'priority'          => $priority,
                                'section'           => $section,
                                'label'             => $title,
                                'description'       => $description,
                            )));
                        break;

                        // Menus Field
                        case 'menus':
                            $wp_customize->add_control( new WPC_Customize_Menus_Control( $wp_customize, esc_attr( $option['id'] ), array(
                                'priority'          => $priority,
                                'section'           => $section,
                                'label'             => $title,
                                'description'       => $description,
                            )));
                        break;

                        // Users Field
                        case 'users':
                            $wp_customize->add_control( new WPC_Customize_Users_Control( $wp_customize, esc_attr( $option['id'] ), array(
                                'priority'          => $priority,
                                'section'           => $section,
                                'label'             => $title,
                                'description'       => $description,
                            )));
                        break;

                        // Posts Field
                        case 'posts':
                            $wp_customize->add_control( new WPC_Customize_Posts_Control( $wp_customize, esc_attr( $option['id'] ), array(
                                'priority'          => $priority,
                                'section'           => $section,
                                'label'             => $title,
                                'description'       => $description,
                            )));
                        break;

                        // Post Types Field
                        case 'post_types':
                            $wp_customize->add_control( new WPC_Customize_Post_Type_Control( $wp_customize, esc_attr( $option['id'] ), array(
                                'priority'          => $priority,
                                'section'           => $section,
                                'label'             => $title,
                                'description'       => $description,
                            )));
                        break;

                        // Tags Field
                        case 'tags':
                            $wp_customize->add_control( new WPC_Customize_Tags_Control( $wp_customize, esc_attr( $option['id'] ), array(
                                'priority'          => $priority,
                                'section'           => $section,
                                'label'             => $title,
                                'description'       => $description,
                            )));
                        break;

                        // CSS editor
                        case 'css_editor':
                            $wp_customize->add_control( new WPC_Customize_CSS_Editor_Control( $wp_customize, esc_attr( $option['id'] ), array(
                                'priority'          => $priority,
                                'section'           => $section,
                                'label'             => $title,
                                'description'       => $description,
                			)));
                        break;

                        // Font
                        case 'font':
                            $wp_customize->add_control( new WPC_Customize_Font_Control( $wp_customize, esc_attr( $option['id'] ), array(
                                'priority'          => $priority,
                                'section'           => $section,
                                'label'             => $title,
                                'description'       => $description,
                			)));
                        break;

                        // Radio Image
                        case 'radio_image':
                            $wp_customize->add_control( new Pix_Customize_Radio_Image_Control( $wp_customize, esc_attr( $option['id'] ), array(
                                'priority'          => $priority,
                                'section'           => $section,
                                'label'             => $title,
                                'description'       => $description,
                                'choices'           => ( isset( $option['choices'] ) ) ? $option['choices'] : array(),
                			)));
                        break;

                    }
                }
            }
        }

        do_action( 'bwpc_create_custom_control', $wp_customize );

    }

}
Bw_customizer::init();

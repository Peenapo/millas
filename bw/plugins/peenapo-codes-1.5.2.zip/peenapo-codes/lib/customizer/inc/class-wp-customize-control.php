<?php
/**
 * WPshed Customizer custom control classes
 */


if( ! class_exists( 'WP_Customize_Control' ) ) { return; }


/**
 * Font
 */
class WPC_Customize_Font_Control extends WP_Customize_Control {

 	public $type = 'textarea';

    protected static $google_fonts;

 	// Render the content
 	public function render_content() {

        $this->load_google_fonts(); ?>

        <div class="bwpc-font-field">

            <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>

            <?php
            $current_value = $this->value();
            if( empty( $current_value ) ) {
                $current_value = array_shift( self::$google_fonts );
            }
            $current_value_json = $current_value;
            ?>

            <!-- font value -->
            <input type="hidden" <?php $this->link(); ?> class="bwpc-font-value" value='<?php echo (string)json_encode( $current_value_json ); ?>'>
            <!-- font family -->
            <select class="bwpc-font-family">
                <option value=""><?php esc_html_e('Select Font', 'peenapo-codes-td'); ?></option>
                <?php foreach ( self::$google_fonts as $key => $font ) {
                    self::get_font_option( $font, $key, $current_value );
                } ?>
            </select>

            <!-- variants -->
            <select class='bwpc-font-variants'>
                <?php if( isset( $current_value->variants ) && ! empty( $current_value->variants ) && is_array( $current_value->variants ) ): ?>
                    <?php echo "<option value=''>" . esc_html__('Select font variant', 'peenapo-codes-td') . "</option>"; ?>
                    <?php foreach ( $current_value->variants as $key => $variant ): ?>
                        <?php echo "<option value='{$variant}'>{$variant}</option>"; ?>
                    <?php endforeach; ?>
                <?php endif; ?>
            </select>

            <!-- subsets -->
            <select class='bwpc-font-subsets' multiple>
                <?php if( isset( $current_value->subsets ) && ! empty( $current_value->subsets ) && is_array( $current_value->subsets ) ): ?>
                    <?php foreach ( $current_value->subsets as $key => $subset ): ?>
                        <?php echo "<option value='{$subset}'>{$subset}</option>"; ?>
                    <?php endforeach; ?>
                <?php endif; ?>
            </select>

        </div><?php

 	}

    protected function get_font_option( $font, $key, $current_value ) {

        $data_variants = '';
        if( isset( $font['variants'] ) and ! empty( $font['variants'] ) and is_array( $font['variants'] ) ) {
            $data_variants = ' data-variants="' . implode(',', $font['variants']) . '"';
        }
        $data_subsets = '';
        if( isset( $font['subsets'] ) ) {
            $data_subsets = ' data-subsets="' . implode(',', $font['subsets']) . '"';
        }
        $selected = '';
        if( isset( $current_value['family'] ) and $current_value['family'] == $font['family'] ) {
            $selected = ' selected="selected"';
        }
        echo "<option value='{$font['family']}'{$data_variants}{$data_subsets}{$selected}>{$font['family']}</option>";
    }

    protected function load_google_fonts() {

        $fonts_path = PCODES_ROOT . 'lib/customizer/resources/google.fonts.php';


        if ( file_exists( $fonts_path ) ) {
			self::$google_fonts = require( $fonts_path );
		}

		if ( ! empty( self::$google_fonts ) ) {
			return apply_filters( 'customify_filter_google_fonts_list', self::$google_fonts );
		}

		return false;
    }

}

/**
 * Radio image
 */
class Pix_Customize_Radio_Image_Control extends Wp_Customize_Control {

    public $type = 'radio_image';
	public $description = null;

	/**
	 * Render the control's content.
	 *
	 * @since 3.4.0
	 */
	public function render_content() { ?>

		<?php if ( ! empty( $this->label ) ) { ?>
			<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
		<?php } ?>

		<div class="bwpc-radio-images">
			<?php
			foreach ( $this->choices as $value => $image_url ) {

				if ( empty( $image_url ) ) {
					$image_url = PCODES_URI . 'lib/customizer/assets/images/default-radio-image.png';
				} ?>
				<label<?php if( $this->value() == $value ) { echo ' class="bwpc-radio-active"'; } ?>>
					<input <?php $this->link(); echo 'name="' .  $this->setting->id . '" type="radio" value="' . esc_attr( $value ) . '"' . selected( $this->value(), $value, false ) .' ></input>';?>
					<img src="<?php echo $image_url; ?>" alt=""></span>
				</label>
			<?php } ?>
		</div>

		<?php if ( ! empty( $this->description ) ) { ?>
			<span class="description customize-control-description"><?php echo $this->description; ?></span>
		<?php }

	}
}

/**
 * Add Custom CSS Editor
 */
class WPC_Customize_CSS_Editor_Control extends WP_Customize_Control {
 	public $type = 'css_editor';

 	/**
 	 * Render the control's content.
 	 * @since 3.4.0
 	 */
 	public function render_content() { ?>
 		<style type="text/css" media="screen">
 			.bwpc_css_editor {
 				display:inline-block;
                width:100%;
 				height:225px;
                margin-top:10px;
 			}
 		</style>

 		<textarea <?php $this->link(); ?> class="css_editor_textarea"><?php echo esc_textarea( $this->value() ); ?></textarea>

        <?php if ( ! empty( $this->label ) ) { ?>
			<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
		<?php } ?>

 		<div class="bwpc_css_editor" id="css_editor_<?php echo esc_html( $this->id ); ?>"></div>

        <?php if ( ! empty( $this->description ) ) { ?>
			<span class="description customize-control-description"><?php echo $this->description; ?></span>
		<?php }

 	 }
 }

/**
 * Add Textarea control
 */
class WPC_Customize_Textarea_Control extends WP_Customize_Control {

	public $type = 'textarea';

	// Render the content
	public function render_content() {
		?>
		<label>
			<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
			<?php if ( ! empty( $this->description ) ) : ?>
			<span class="description customize-control-description"><?php echo $this->description; ?></span>
			<?php endif; ?>
			<textarea class="large-text" cols="20" rows="5" <?php $this->link(); ?>>
				<?php echo esc_textarea( $this->value() ); ?>
			</textarea>
		</label>
		<?php
	}

}


/**
 * Add Categories control
 */
class WPC_Customize_Categories_Control extends WP_Customize_Control {

    public $type = 'categories';

 	// Render the content
    public function render_content() {

        $dropdown = wp_dropdown_categories(
            array(
                'name'              => '_customize-dropdown-categories-' . $this->id,
                'echo'              => 0,
                'show_option_none'  => __( '&mdash; Select &mdash;', 'peenapo-codes-td' ),
                'option_none_value' => '0',
                'hierarchical'      => 1,
                'selected'          => $this->value(),
            )
        );

        // Hackily add in the data link parameter.
        $dropdown = str_replace( '<select', '<select ' . $this->get_link(), $dropdown );

        printf(
            '<label class="customize-control-select"><span class="customize-control-title">%s</span><span class="description customize-control-description">%s</span> %s</label>',
            $this->label,
            esc_html( $this->description ),
            $dropdown
        );

    }
}


/**
 * Add Menus control
 */
class WPC_Customize_Menus_Control extends WP_Customize_Control {

	public $type = 'menus';
    private $menus = false;

    public function __construct( $manager, $id, $args = array(), $options = array() ) {

        $this->menus = wp_get_nav_menus( $options );
        parent::__construct( $manager, $id, $args );

    }

    // Render the content
    public function render_content() {

        if( empty( $this->menus ) )
        	return;
            ?>

	        <label class="customize-control-select">
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
				<?php if ( ! empty( $this->description ) ) : ?>
				<span class="description customize-control-description"><?php echo $this->description; ?></span>
				<?php endif; ?>
	            <select <?php $this->link(); ?>>
	            <option value=""><?php _e( '&mdash; Select &mdash;' ); ?></option>
	            <?php
	            	foreach ( $this->menus as $menu ) {
	                    printf( '<option value="%s" %s>%s</option>',
	                    	$menu->term_id,
	                    	selected( $this->value(), $menu->term_id, false ),
	                    	$menu->name
	                    );
	                }
	            ?>
	            </select>
	        </label>
       	<?php
    }
}


/**
 * Add Users control
 */
class WPC_Customize_Users_Control extends WP_Customize_Control {

	public $type = 'users';
    private $users = false;

    public function __construct( $manager, $id, $args = array(), $options = array() ) {

        $this->users = get_users( $options );
        parent::__construct( $manager, $id, $args );

    }

    // Render the content
    public function render_content() {

        if( empty( $this->users) )
        	return;
            ?>

	        <label class="customize-control-select">
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
				<?php if ( ! empty( $this->description ) ) : ?>
				<span class="description customize-control-description"><?php echo $this->description; ?></span>
				<?php endif; ?>
				<select <?php $this->link(); ?>>
				<option value=""><?php _e( '&mdash; Select &mdash;' ); ?></option>
				<?php
					foreach( $this->users as $user ) {
                        printf( '<option value="%s" %s>%s</option>',
	                        $user->data->ID,
	                        selected( $this->value(), $user->data->ID, false ),
	                        $user->data->display_name
                        );
	                }
	            ?>
				</select>
			</label>
		<?php
    }
}


/**
 * Add Posts control
 */
class WPC_Customize_Posts_Control extends WP_Customize_Control {

	public $type = 'posts';
    private $posts = false;

    public function __construct( $manager, $id, $args = array(), $options = array() ) {

        $postargs = wp_parse_args( $options, array( 'numberposts' => '-1' ) );
        $this->posts = get_posts( $postargs );
        parent::__construct( $manager, $id, $args );
    }

    // Render the content
    public function render_content() {

        if( empty( $this->posts) )
        	return;
            ?>
            <label class="customize-control-select">
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
				<?php if ( ! empty( $this->description ) ) : ?>
				<span class="description customize-control-description"><?php echo $this->description; ?></span>
				<?php endif; ?>
                <select <?php $this->link(); ?>>
                <option value=""><?php _e( '&mdash; Select &mdash;' ); ?></option>
                <?php
                    foreach ( $this->posts as $post ) {
                        printf( '<option value="%s" %s>%s</option>',
                        	$post->ID,
                        	selected( $this->value(), $post->ID, false ),
                        	$post->post_title
                        );
                    }
                ?>
                </select>
            </label>
        <?php
    }
}


/**
 * Add Post Types control
 */
class WPC_Customize_Post_Type_Control extends WP_Customize_Control {

    public $type = 'post_types';
    private $post_types = false;

    public function __construct( $manager, $id, $args = array(), $options = array() ) {

        $postargs = wp_parse_args( $options, array( 'public' => true ) );
        $this->post_types = get_post_types( $postargs, 'object' );
        parent::__construct( $manager, $id, $args );

    }

    // Render the content
    public function render_content() {

        if( empty( $this->post_types ) )
        	return;
        	?>
            <label class="customize-control-select">
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
				<?php if ( ! empty( $this->description ) ) : ?>
				<span class="description customize-control-description"><?php echo $this->description; ?></span>
				<?php endif; ?>
                <select <?php $this->link(); ?>>
                <option value=""><?php _e( '&mdash; Select &mdash;' ); ?></option>
                <?php
         			foreach ( $this->post_types as $k => $post_type ) {
                        printf('<option value="%s" %s>%s</option>',
                        	$k,
                        	selected( $this->value(), $k, false ),
                        	$post_type->labels->name
                        );
                    }
                ?>
                </select>
            </label>
        <?php
    }
}


/**
 * Add Tags control
 */
class WPC_Customize_Tags_Control extends WP_Customize_Control {

	public $type = 'tags';
    private $tags = false;

    public function __construct( $manager, $id, $args = array(), $options = array() ) {

        $this->tags = get_tags( $options );
        parent::__construct( $manager, $id, $args );

    }

    // Render the content
    public function render_content() {
        if( empty( $this->tags ) )
        	return;
        ?>
            <label class="customize-control-select">
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
				<?php if ( ! empty( $this->description ) ) : ?>
				<span class="description customize-control-description"><?php echo $this->description; ?></span>
				<?php endif; ?>
                <select <?php $this->link(); ?>>
                <option value=""><?php _e( '&mdash; Select &mdash;' ); ?></option>
                <?php foreach ( $this->tags as $tag ) {
                        printf( '<option value="%s" %s>%s</option>',
                            $tag->term_id,
                            selected( $this->value(), $tag->term_id, false ),
                            $tag->name
                        );
                    }
                ?>
                </select>
            </label>
        <?php
    }
}

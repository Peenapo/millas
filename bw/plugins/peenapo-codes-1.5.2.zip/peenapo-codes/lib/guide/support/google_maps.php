<?php $google_api_key_enabled = Bw_guide::get_google_api_key(); ?>
<div class="bwg-alert<?php if( $google_api_key_enabled ) { echo ' bwg-alert-success'; } ?>">
    <strong><?php echo $google_api_key_enabled ? Bw_guide::get_string('complete') : Bw_guide::get_string('not_complete'); ?></strong>
</div>
<div class="bwg-tab-content">
    <h3><?php esc_html_e('Setup Google Map', 'peenapo-codes-td'); ?></h3>
    <p>
        <?php esc_html_e('In order to use the geolocation and Google Maps features you need to add a Google Maps API key.', 'peenapo-codes-td'); ?>
    </p>
    <a href="https://developers.google.com/maps/documentation/javascript/get-api-key#get-an-api-key" target="_blank" class="bwg-button button button-secondary"><?php esc_html_e('How to Create a Key', 'peenapo-codes-td'); ?></a>&nbsp;
    <br><br><p><?php esc_html_e('Once generated, add the token below:', 'peenapo-codes-td'); ?></p>
    <form class="bwg-input-google-key-form" action="post" name="bwg-input-google-key-form" id="bwg-input-google-key-form">
        <?php wp_nonce_field( 'ajax-nonce' ); ?>
        <input type="text" name="api_key" value="<?php echo esc_attr( Bw_guide::get_google_api_key() ); ?>" placeholder="<?php esc_html_e('Google Api Key', 'peenapo-codes-td'); ?>">
    </form>
    <a href="#" id="bwg-do-google-key" class="bwg-button button button-primary"><?php esc_html_e('Save Google Maps Api Key', 'peenapo-codes-td'); ?></a>
</div>

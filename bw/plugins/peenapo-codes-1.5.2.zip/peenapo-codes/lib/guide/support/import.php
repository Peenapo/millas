<?php $was_imported = get_option( Bw::$theme_prefix . '_demo_was_imported', false ); ?>
<div class="bwg-alert<?php if( $was_imported ) { echo ' bwg-alert-success'; } ?>">
    <strong data-complete="<?php echo Bw_guide::get_string('demo_complete'); ?>"><?php echo $was_imported ? Bw_guide::get_string('demo_complete') : Bw_guide::get_string('demo_not_complete'); ?></strong>
</div>
<div id="bw-import-content" class="bwg-tab-content">
    <h3><?php esc_html_e('Import Demo Content', 'peenapo-codes-td'); ?></h3>
    <p><?php esc_html_e('The demo content will override the existing settings. Choose the demo version you want and then click the button Import Demo Content.', 'peenapo-codes-td'); ?></p>
    <p><?php esc_html_e('System status:', 'peenapo-codes-td'); ?></p>
    <?php echo Bw_guide::check_system(); ?>
    <p><?php esc_html_e('Select demo version:', 'peenapo-codes-td'); ?></p>
    <?php $demo_versions = Bw_guide::$demo_versions; ?>
    <?php if( count( $demo_versions ) > 0 ) {
        echo '<ul class="bw-demo-choices">';
        foreach ( $demo_versions as $key => $demo_version ) {
            $demo_img = BW_URI . 'bw/demo/' . ( $key + 1 ) . '/screenshot.png';
            echo '<li class="bw-table">';
            if( @getimagesize( $demo_img ) ) {
                echo '<div class="bw-cell bw-demo-choice-left">'.
                    '<img src="' . esc_url( $demo_img ) . '" alt="">'.
                '</div>';
            }
            echo '<div class="bw-cell bw-demo-choice-right">'.
                    '<h4>' . esc_attr( $demo_version->label ) . '</h4>'.
                    '<p>' . esc_html( $demo_version->description ) . '</p>'.
                '</div>'.
            '</li>';
        }
        echo '</ul>';
    } ?>
    <div id="bwg-import-results" class="bwg-import-results bwg-hidden">
        <p><?php esc_html_e('Import results:', 'peenapo-codes-td'); ?></p>
        <p class="bwg-palert"><?php esc_html_e('Please do not close or refresh the page! This could take several minutes, depending on your internet connection.', 'peenapo-codes-td'); ?></p>
        <ul></ul>
    </div>
    <a href="#" id="bwg-do-import" class="bwg-button button button-primary" disabled="disabled" data-imported="<?php esc_html_e('Demo Content Successfully Imported', 'peenapo-codes-td'); ?>" data-importing="<?php esc_html_e('Importing Demo Content..', 'peenapo-codes-td'); ?>" data-active="<?php esc_html_e('Import Demo Content', 'peenapo-codes-td'); ?>"><?php esc_html_e('Please Select Demo Version', 'peenapo-codes-td'); ?></a>
</div>

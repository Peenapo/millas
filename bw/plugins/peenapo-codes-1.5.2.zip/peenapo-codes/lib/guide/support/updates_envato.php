<?php $api = Bw_Envato_Market_API::instance(); ?>
<div class="bwg-alert<?php if( $api->can_make_request_with_token() ) { echo ' bwg-alert-success'; } ?>">
    <strong><?php echo $api->can_make_request_with_token() ? Bw_guide::get_string('api_complete') : Bw_guide::get_string('api_not_complete'); ?></strong>
</div>
<div class="bwg-tab-content">
    <h3><?php esc_html_e('Enable Automatic Updates', 'peenapo-codes-td'); ?></h3>
    <p><?php esc_html_e('We aim to keep our themes updated as bugs are discovered and fixed or as new features are introduced. Generate a new token to obtain the new cool stuff automatically.', 'peenapo-codes-td'); ?></p>
    <a href="https://build.envato.com/create-token/?purchase:download=t&purchase:verify=t&purchase:list=t" target="_blank" class="bwg-button button button-secondary"><?php esc_html_e('Generate a Token', 'peenapo-codes-td'); ?></a>
    <br><br><p><?php esc_html_e('Once generated, add the token below:', 'peenapo-codes-td'); ?></p>
    <form class="bwg-input-token-form" action="post" name="bwg-input-token-form" id="bwg-input-token-form">
        <?php wp_nonce_field( 'ajax-nonce' ); ?>
        <input type="text" name="token" value="<?php echo esc_attr( Bw_guide::get_envato_updater_token() ); ?>" placeholder="<?php esc_html_e('Token', 'peenapo-codes-td'); ?>">
    </form>
    <a href="#" id="bwg-do-updates_envato" class="bwg-button button button-primary"><?php esc_html_e('Save Token', 'peenapo-codes-td'); ?></a>
</div>

<div class="bwg-tab-content">
    <h3><?php esc_html_e('Customize Your Site', 'peenapo-codes-td'); ?></h3>
    <p><?php esc_html_e('The best part! The Live Customizer allows users to tweak theme settings using a WYSIWYG interface and customize the theme so it includes the colors, fonts, text - and pretty much anything else.', 'peenapo-codes-td'); ?></p>
    <a href="<?php echo esc_url( admin_url( 'customize.php' ) ); ?>" class="bwg-button button button-primary"><?php esc_html_e('Launch Customizer', 'peenapo-codes-td'); ?></a>
</div>

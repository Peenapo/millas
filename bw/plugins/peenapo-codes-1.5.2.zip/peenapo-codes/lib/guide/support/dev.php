<div class="bwg-tab-content bwg-tab-involved">

    <h3><?php esc_html_e('Development', 'peenapo-codes-td'); ?></h3>
    <p><?php esc_html_e("Theme options:", 'peenapo-codes-td'); ?></p>

    <?php // Get an array of all the theme mods

    # get options
    $mods_export = '';
    if( defined('BW_FRAME_LIB') ) {
        $customizer_mods_file = BW_FRAME_LIB . 'customizer/customizer-mods.php';
        if( file_exists( $customizer_mods_file ) ) {
            require $customizer_mods_file;
            $options_arr = array();
            foreach( $options as $option ) {
                $value = get_option( $option['id'] );
                if( empty( $value ) ) {
                    if( isset( $option['default'] ) ) {
                        $value = $option['default'];
                    }
                }
                $site_url = get_site_url();
                if( strpos( $value, $site_url ) !== false  ) {
                    $value = str_replace( $site_url, '%BW_SITE_URL%', $value );
                }
                $options_arr[ $option['id'] ] = $value;
            }
            $mods_export = maybe_serialize( $options_arr );
        }
    }

    ?>

    <textarea id="bwg_theme_mods_export" name="bwg_theme_mods_export"><?php echo $mods_export; ?></textarea>
    <a href="<?php echo esc_url( admin_url( 'customize.php' ) ); ?>" class="bwg-button button button-primary"><?php esc_html_e('Launch Customizer', 'peenapo-codes-td'); ?></a>

</div>

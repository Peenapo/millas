<div class="bwg-tab-content bwg-tab-involved">
    <div class="bwg-tab-involved-col bwg-tab-involved-left">
        <h3><?php esc_html_e('Get Involved', 'peenapo-codes-td'); ?></h3>
        <p><?php esc_html_e('If you like the theme please rate us on Facebook, it is very important to improve our work.', 'peenapo-codes-td'); ?></p>
        <a href="https://www.facebook.com/pg/Peenapo/reviews/" target="_blank" class="bwg-button button button-highlight"><?php esc_html_e('Rate us on Facebook', 'peenapo-codes-td'); ?></a>
        <br><br><p><?php esc_html_e('Like our Facebook Fan Page and see what are we working on. We also like to mention the outstanding work of our customers.', 'peenapo-codes-td'); ?></p>
    </div>
    <div class="bwg-tab-involved-col bwg-tab-involved-right">
        <div id="fb-root"></div>
        <script>(function(d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) return;
            js = d.createElement(s); js.id = id;
            js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.8&appId=476619369072929";
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));</script>
        <div class="fb-page" data-href="https://www.facebook.com/Peenapo/" data-tabs="timeline" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/Peenapo/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/Peenapo/"><?php esc_html_e('Peenapo - Creative Wordpress Themes', 'peenapo-codes-td'); ?></a></blockquote></div>
    </div>
</div>

# Peenapo-Codes
Core functions for Peenapo themes, awesomeness and more.

# Changelog

v1.5.2
- fixed: repeater not binding number slider option
- added: customizer empty font, and default seld hosted font
- added: Overpass Google Font
- added: Scope One Google Font
- added: static variable ACF_PRODUCTION replaced with BW_PRODUCTION
- improved: enqueue google fonts
- improved: readability of the google fonts resource file
- improved: added some php checks to prevent warnings and errors
- improved: import demo content, added automatic customizer options export for production
- fixed: php warning

v1.5.1
- dev section, now exports all the theme options from customizer-mods.php options array
- added: customizer - support for input attributes in text fields
- fixed: customizer - number range fiend css layout issue

v1.5
- removed: acf gallery field
- improved: font awesome replaced with 7-stroke line icons
- improved: now updates via peenapo.com
- replaced: option tree replaced with wp live customizer
- added: translation POT file
- added: customizer options are now global, default saving type: 'option', changed from 'theme_mod'
- fixed: automatic acf export not works with child themes

v1.4
- added: option tree
- added: wp importer library

v1.3
- fixed: per-image custom theme on-off settings not begin checked
- fixed: ACF plugins not loading correctly in front-end
- fixed: updater
- fixed: radio button image missing conditional logic

v1.2
- fixed: acf - when creating a new field group - standard (wp metabox) is selected by default
- fixed: acf - radio image bug
- fixed: php conflict with updater.php

v1.1
- moved: updater
- moved: acf plugins

v1.0

- Initial Release

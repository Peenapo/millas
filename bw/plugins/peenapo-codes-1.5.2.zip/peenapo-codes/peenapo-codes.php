<?php
/*
Plugin Name: Peenapo Codes
Plugin URI: http://peenapo.com
Description: Core functions for Peenapo themes, awesomeness and more.
Version: 1.5.2
Author: Peenapo
Author URI: http://peenapo.com
Text Domain: peenapo-codes-td
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if( ! function_exists( 'd' ) ) {
	function d($what) {
		print '<pre>';
		print_r($what);
		print '</pre>';
	}
}

if( ! defined( 'PCODES_ROOT' ) ) {
    define( 'PCODES_ROOT', plugin_dir_path( __FILE__ ) );
}
if( ! defined( 'PCODES_URI' ) ) {
    define( 'PCODES_URI', plugins_url( '/', __FILE__ ) );
}
if( ! defined( 'PCODES_SLUG' ) ) {
    define( 'PCODES_SLUG', plugin_basename(__FILE__) );
}

add_action( 'plugins_loaded', array( 'Pcodes', 'load_textdomain' ) );

require_once( PCODES_ROOT . 'core/Pcodes.php' );
require_once( PCODES_ROOT . 'core/Pcodes_guide.php' );

Pcodes::init();
